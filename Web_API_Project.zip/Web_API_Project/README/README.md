 Aplicación web para rastrear lanzamientos de juegos de Ubisoft con countdown en tiempo real

🎮 Ubisoft Release Tracker
Aplicación web moderna para rastrear próximos lanzamientos de juegos de Ubisoft con countdown en tiempo real.

✨ Características
🕒 Countdown en tiempo real para cada juego
🔍 Búsqueda y filtros por género, plataforma y fecha
📱 Diseño responsive para móviles y desktop
🎨 Interfaz moderna con animaciones suaves
♿ Totalmente accesible con soporte para lectores de pantalla
🚀 API RAWG para datos actualizados
🛠️ Tecnologías Utilizadas
HTML5 - Estructura semántica
CSS3 - Diseño moderno con gradientes y animaciones
JavaScript - Funcionalidad interactiva
RAWG API - Datos de juegos en tiempo real
GitHub Pages - Despliegue gratuito
📱 Capturas de Pantalla
Desktop
![alt text](image.png)
![alt text](image-1.png)
![alt text](image-2.png)
Mobile
![alt text](image-3.png)
![alt text](image-4.png)
![alt text](image-5.png)

🚀 Instalación Local
Clonar el repositorio
git clone https://github.com/TU-USUARIO/ubisoft-release-tracker.git
cd ubisoft-release-tracker