// src/routes/Home.jsx
import React from 'react';
import GameList from './GameList';

export default function Home(){
  return (
    <main>
      <GameList />
    </main>
  );
}

