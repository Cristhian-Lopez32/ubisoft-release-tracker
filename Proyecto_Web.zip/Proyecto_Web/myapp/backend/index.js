// backend/index.js
const express = require('express')
const cors = require('cors')
const bcrypt = require('bcrypt')
const jwt = require('jsonwebtoken')
const path = require('path')

const { Low } = require('lowdb')
const { JSONFile } = require('lowdb/node')

// ---- Configuración DB ----
const DB_PATH = path.join(__dirname, 'db.json')
const adapter = new JSONFile(DB_PATH)
const db = new Low(adapter, { users: [], events: [] })


// Inicializar la BD
async function initDB() {
  await db.read();
  db.data ||= { users: [], events: [] };
  await db.write();
}

initDB()

// ---- Configuración App ----
const app = express()
app.use(cors())
app.use(express.json())

const PORT = process.env.PORT || 4000
const JWT_SECRET = process.env.JWT_SECRET || 'dev_secret_change_me'

// ---- Middleware Auth ----
function authMiddleware(req, res, next) {
  const header = req.headers['authorization']
  if (!header) return res.status(401).json({ error: 'No token' })
  const token = header.split(' ')[1]
  try {
    const decoded = jwt.verify(token, JWT_SECRET)
    req.user = decoded
    next()
  } catch (err) {
    return res.status(401).json({ error: 'Invalid token' })
  }
}

// ---- Rutas Auth ----
app.post('/api/auth/register', async (req, res) => {
  const { username, email, password } = req.body
  if (!username || !email || !password) {
    return res.status(400).json({ error: 'Campos requeridos' })
  }

  await db.read()
  const existing = db.data.users.find(
    u => u.email === email || u.username === username
  )
  if (existing) {
    return res.status(400).json({ error: 'Usuario ya existe' })
  }

  const hashed = await bcrypt.hash(password, 10)
  const user = { id: Date.now().toString(), username, email, password: hashed, role: 'user' }
  db.data.users.push(user)
  await db.write()

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role }, token })
})

// ---- Rutas de Eventos ----
app.get('/api/events', authMiddleware, async (req, res) => {
  await db.read()
  res.json({ events: db.data.events || [] })
})

app.post('/api/events', authMiddleware, async (req, res) => {
  const { title, date } = req.body
  if (!title || !date) {
    return res.status(400).json({ error: 'Faltan campos' })
  }
  await db.read()
  db.data.events ||= []
  const event = { id: Date.now().toString(), title, date, owner: req.user.id }
  db.data.events.push(event)
  await db.write()
  res.json({ event })
})


app.post('/api/auth/login', async (req, res) => {
  const { identifier, password } = req.body
  await db.read()
  const user = db.data.users.find(
    u => u.email === identifier || u.username === identifier
  )
  if (!user) return res.status(400).json({ error: 'Usuario no encontrado' })

  const ok = await bcrypt.compare(password, user.password)
  if (!ok) return res.status(400).json({ error: 'Credenciales inválidas' })

  const token = jwt.sign({ id: user.id, role: user.role }, JWT_SECRET, { expiresIn: '1h' })
  res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role }, token })
})

app.get('/api/auth/me', authMiddleware, async (req, res) => {
  await db.read()
  const user = db.data.users.find(u => u.id === req.user.id)
  if (!user) return res.status(404).json({ error: 'Usuario no encontrado' })
  res.json({ user: { id: user.id, username: user.username, email: user.email, role: user.role } })
})

// ---- Rutas protegidas ejemplo ----
app.get('/api/admin/data', authMiddleware, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'No autorizado' })
  }
  res.json({ secret: 'Solo admins pueden ver esto 🚀' })
})

app.listen(PORT, () => {
  console.log(`Backend escuchando en http://localhost:${PORT}`)
})
