// src/components/Header.jsx
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

export default function Header(){
  const { user, logout } = useAuth();
  return (
    <header className="site-header">
      <h1>Mi Web — Releases</h1>
      <div className="controls">
        <Link to="/"><button className="btn">Home</button></Link>
        {!user ? (
          <>
            <Link to="/login"><button className="btn">Iniciar sesión</button></Link>
            <Link to="/register"><button className="btn">Registrarse</button></Link>
          </>
        ) : (
          <>
            <Link to="/events"><button className="btn">Eventos</button></Link>
            <button className="btn" onClick={() => { logout(); }}>Cerrar sesión</button>
          </>
        )}
      </div>
    </header>
  );
}
