// src/context/AuthContext.jsx
import React, { createContext, useContext, useEffect, useState } from 'react';
import { loadFromStorage, saveToStorage } from '../utils/storage';

const USERS_KEY = 'app_users_v1';
const CURRENT_USER_KEY = 'app_current_user_v1';
const AuthContext = createContext();

export function AuthProvider({children}){
  const [user, setUser] = useState(null);

  useEffect(()=>{
    const u = loadFromStorage(CURRENT_USER_KEY, null);
    if (u) setUser(u);
  },[]);

  function getUsers(){ return loadFromStorage(USERS_KEY, []); }
  function setUsers(u){ saveToStorage(USERS_KEY, u); }

  function register({username, email, password}){
    const users = getUsers();
    if (users.some(x => x.username.toLowerCase()===username.toLowerCase())) {
      throw new Error('Nombre de usuario ya existe');
    }
    if (users.some(x => x.email.toLowerCase()===email.toLowerCase())) {
      throw new Error('Correo ya registrado');
    }
    const newUser = { id: 'u_'+Date.now(), username, email, passwordHash: btoa(password), createdAt: new Date().toISOString() };
    users.push(newUser);
    setUsers(users);
    saveToStorage(CURRENT_USER_KEY, newUser);
    setUser(newUser);
    return newUser;
  }

  function login({identifier, password}){
    const users = getUsers();
    const hash = btoa(password);
    const u = users.find(x => (x.username.toLowerCase()===identifier.toLowerCase() || x.email.toLowerCase()===identifier.toLowerCase()) && x.passwordHash === hash);
    if (!u) throw new Error('Credenciales inválidas');
    saveToStorage(CURRENT_USER_KEY, u);
    setUser(u);
    return u;
  }

  function logout(){
    localStorage.removeItem(CURRENT_USER_KEY);
    setUser(null);
  }

  return <AuthContext.Provider value={{user, register, login, logout}}>{children}</AuthContext.Provider>;
}

export function useAuth(){ return useContext(AuthContext); }
